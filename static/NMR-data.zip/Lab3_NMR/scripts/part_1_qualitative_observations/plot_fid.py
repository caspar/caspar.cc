if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import sys
    sys.path.append("../python_scripts")
    from NMR_Data_Driver import DataDriver
    data_path = "../../data/Part 1 - qualitative observations/0_initialSpecFreq/"
    driver = DataDriver()
    title='Free Induction Decay of 10mM CuSO4'
    driver.load_data(fname=data_path+"correctFID.txt")
    driver.plot_fid(outfileName='fid',title=title)
    plt.show()
