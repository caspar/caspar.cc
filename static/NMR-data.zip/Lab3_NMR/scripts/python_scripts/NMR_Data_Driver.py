import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import scipy.optimize
# import sys
import os
import re
import scipy.integrate as integrate

def fitfunc(t, A, T, y0):
    '''
    Inputs:
    t - (array of floats) independent variable, times
    A - (float) amplitude of exponential
    T - (float) relaxation time
    y0 - (float) intercept

    Define exponential function for fit to data
    '''
    return A*np.exp(-t/T) + y0
    
def intsimps(y,x,x1,x2):
    '''
    Inputs:
    y - (array of floats) function evaluations to represent height of integrand
    x - (array of floats) array of values of independent value at which f is
    evaluated
    x1 - (float) value of x to start region of integration
    x2 - (float) value of x to start region of integration

    Array y is considered a function of array x
    We integrate y as function of x in the range of x1 to x2,
    '''
    x0 = x[0]
    dx = x[1] - x[0]
    i1 = int(np.floor((x1-x0)/dx))  # index of starting value of x
    i2 = int(np.floor((x2-x0)/dx)) # index of ending value of x
    assert isinstance(i1,int), "i1 is not of type int"
    assert isinstance(i2,int), "i1 is not of type int"
    return integrate.simps(y.values[i1:i2],None,dx)

def angleRotateReal(z):
    '''
    Given a complex number, this returns the angle that rotates that complex
    number into a real number without changing the sign of the real part. 
    '''
    lr = (1 - 1*np.real(np.sign(z)))/2.0 # 0 if right half-plane and 
                                         # 1 if left half-plane
    angle = np.angle(z)
    if (lr * np.pi - angle) < np.pi:
        return (lr * np.pi - angle)
    else:                             # this statement is not necessary, but it
        return (lr-2) * np.pi - angle # keeps the angles between -180 and +180  

def complexArrayToReal(zsignal):
    '''
    This takes an array of complex numbers and returns an array of the same size
    of real numbers, which can be used for fitting to an exponential.
    '''
    realsignal = np.array([])

    # print 'zsignal = ', zsignal
    # rotangle is the angle for rotation of first point of zsignal onto negative
    # real axis.
    print('Rotation angles of consecutive data points:')
    print('-------------------------------------------')
    rotangle = np.pi - np.angle(zsignal[0]) # rotate to negative real axis
    if rotangle > np.pi:              # this statement is not necessary, but it
        rotangle = rotangle - 2*np.pi # keeps the angles between -180 and +180
                                      
    print('rotation angle = {: 2.2f} degrees'.format((180/np.pi) *
        rotangle))

    # rotate all points in the array by this angle.
    zsignal = np.exp(1j * rotangle)*zsignal
    realsignal = np.append(realsignal,zsignal[0].real)
    
    for i in range(1,len(zsignal)): # start with 2nd point (1st already rotated)
    
        # return smallest angle that rotates i'th element to real axis
        rotangle = angleRotateReal(zsignal[i]) 
        print('rotation angle = {: 2.2f} degrees'.format((180/np.pi) *
            rotangle))

        ## limit rotation angle to 45 degrees (pi/4)        
        #if np.abs(rotangle) > np.pi/4:
        #    rotangle = np.pi/4 * rotangle/abs(rotangle)
        #    print '* corrected angle = ',(180/np.pi) * rotangle, 'degrees'

        # rotate all elements in the array by this amount 
        # (ith element will become real).
        zsignal = np.exp(1j * rotangle) * zsignal 
        
        # append ith element of zsignal to realsignal
        realsignal = np.append(realsignal,zsignal[i].real)
        # print 'realsignal = ', realsignal
    return realsignal

class DataDriver(object):
    def __init__(self):
        print("Initializaing the data driver...")

    # this implements analyze_plot_ispin_echo_sweep_data
    def load_data( self, fname , verbose=True ):
        '''
        This reads in complex data from a file and outputs a tuple,
        where t is the time data and za is an array of complex numbers
        corresponding to the time data

        Inputs:
            fname - (string) input filename of file to parse
        Outputs:
            None - sets state variables data and metadata
        '''
        with open(fname,'r') as file_handle:
            file_text = file_handle.read()
        bandwidth_re = re.compile('@SW= ([0-9.]+)')
        if bandwidth_re.findall(file_text):
            bw = float(bandwidth_re.findall( file_text )[0])
        else:
            print("Could not parse bandwidth. Exiting")
            return
        df = pd.read_csv(fname, skiprows=13, names=['data'])
        if verbose:
            print(df.describe())
        print("Bandwidth: {}".format(bw)) # Note that the time interval between points is 1/bw
        npts = df.shape[0]/2
        print('npts = {}'.format(npts))
        t =  (1/bw)*np.arange(npts)  #time data
        # assign the data to variables with shorter names
        s = df['data']
        rs = s.values.reshape(-1,2)
        data = pd.DataFrame({'time':t,'complex':rs[:,0]+1j*rs[:,1],'real':rs[:,0],'imag':rs[:,1]})
        data['fza'] = np.fft.fftshift(np.fft.fft(data['complex']))
        data['freq'] = (bw/npts)*np.arange(npts)-bw/2
        metadata = {'bandwidth':bw}
        self.data = data
        self.metadata = metadata

    # this implements manipulate_plot_ispin_nmr_data
    def plot_fid( self , sf=50 , outfileName="",title="" ):
        """
        Plot the (FID) free induction decay.
        Display a plot of the time and frequency data.

        Inputs:
        t - (array of floats) time axis
        za - (array of complex values) complex amplitudes of signal
        f - (array of floats) frequency axis
        fza - (array of floats) fft of complex amplitude
        sf - (float) scale factor for frequency
        outfileName - (string) name of output file to be generated
        Outputs:
        None
        """
        fig1   = plt.figure(figsize=(8,10))
        ax1    = fig1.add_subplot(211)  # this will show that time data
        ax2    = fig1.add_subplot(212)  # this will show the frequency data
        # print 'len(az.real)=',len(za.real)
        # print 'len(t)=',len(t)

        tscale = 1000.0   # change time units to msec
        tunits = r'$\mu$s'
        fscale = 1/tscale
        funits = 'kHz'

        t = self.data['time']
        za = self.data['complex']

        ax1.plot(t*tscale,za.real, '-b',label='Real Part of Signal')  # real part (blue)
        ax1.plot(t*tscale,za.imag, '-r',label='Imaginary Part of Signal')  # imaginary part (red)

        ax1.set_xlabel('Time ('+np.str(tunits)+')',fontsize=14)
        ax1.set_ylabel('Signal',fontsize=14)

        ax1.set_xlim(t.values[0]*tscale,t.values[-1]*tscale)
        ax1.legend()

        f = self.data['freq']
        fza = self.data['fza']
        ax2.plot(f*fscale,fza.real, '-b',label='Real Part of Signal')  # real part (blue)
        ax2.plot(f*fscale,fza.imag, '-r',label='Imaginary Part of Signal')  # imaginary part (red)

        # plot the magnitude (black)
        ax2.plot(f*fscale,np.sqrt(fza.real**2 + fza.imag**2),
        '-k',label='Magnitude of Signal')

        ax2.set_xlabel('Frequency ('+np.str(funits)+')',fontsize=14)
        ax2.set_ylabel('Signal',fontsize=14)

        [fmin,fmax] = [f.values[0]/sf,f.values[-1]/sf]
        ax2.set_xlim(fmin*fscale,fmax*fscale)
        ax2.legend()
        plt.suptitle(title,fontsize=20)
        if outfileName:
            plt.savefig(outfileName+".png",format='png')

    # this implements ispin_nmr_cpmg_analysis
    def cpmg_analysis( self , fname = "" ):
        '''
        Inputs:
        fname - (string) filename containing the data

        Plot and analyze CPMG data.
        N points are taken from the top of each echo.  
        The data are generated in the Spincore LabView interface from the specification of the number of points per echo, N.  
        At the beginning of the FID, and in the middle of each echo, N points are 
        collected at the rate given by the parameter 'SW' in the LabVeiw interface, 
        (or 'bw' in this program).  The N points from each echo are averaged, and the
        average is plotted as a function of the time of the given echo.  The data are
        fit to a decaying exponential, from which the value of T2 can be extracted.  
        ###########################################################################
        Set the folowing parameters based on values from SpinCore LabView interface
        ###########################################################################
        '''
        tau = 20*10**(-3)     # Obtained from value of tau in SpinCore LabView interface
        numave = 5            # Number of points/echo, or number of adjacent points to 
                              # average.  Obtained from SpinCore LabView interface
        '''
        ###########################################################################
        Set the above parameters based on values from SpinCore LabView interface
        ###########################################################################
        Average over each set of 'numave' consecutive points in the data.  'numave' is
        the number of points per echo (from LabView interface).  This produces data
        consisting of Necho points (including the FID).  These data will be fit to an 
        exponential function to determine the value of T2.  
        '''
        self.load_data( fname )
        complex_reshape = abs(self.data['complex'].reshape(len(self.data['complex'])/numave,numave))
        expdata = np.apply_along_axis(sum,1,complex_reshape)/numave
        print('expdata={}'.format(expdata))
        print('len(expdata)={}'.format(len(expdata)))
        texpdata = tau*np.arange(len(expdata))  # times of each echo
        '''
        Fit the data to an exponential function: a exp(-t/T2) + c
        '''
        # initial guesses of the parameters: modify these if fit doesn't converge.
        A0 = expdata[0];  # Value of initial point (FID amplitude)   
        T20 = 0.02;
        y00 = 0;
        # This is the function that does the nonlinear fit:
        nlfit, nlpcov = scipy.optimize.curve_fit(fitfunc, texpdata, expdata, p0=[A0, T20, y00], sigma=None)
        # These are the parameter estimates (assigned to more readible names):
        A_nlfit = nlfit[0]
        T2_nlfit = nlfit[1]
        y0_nlfit = nlfit[2]
        '''
        Below are the uncertainties in the estimates:  (note that "nlpcov" is the 
        "covariance matrix".  The diagonal elements of the covariance matrix (nlpcov[i][i]) 
        are the variances of the fit parameters, whose square roots give the standard 
        deviation or uncertainties in the fit parameters.  The off-diagonal elements give 
        the correlations between fit parameters.  
        '''
        Asig_nlfit =  np.sqrt(nlpcov[0][0])
        T2sig_nlfit = np.sqrt(nlpcov[1][1])
        y0sig_nlfit = np.sqrt(nlpcov[2][2])
        print('=================')
        print(' Fit Parameters  ')
        print('=====================================================')
        print('T2 = ',T2_nlfit,  '+/- ', T2sig_nlfit)
        print('A  = ',A_nlfit,    '+/- ', Asig_nlfit)
        print('y0 = ',y0_nlfit,  '+/- ', y0sig_nlfit)
        print('=====================================================')
        
        fig1   = plt.figure(1, figsize = (8,9) )
        sp1    = fig1.add_subplot(211)  # this will show that time data
        sp2    = fig1.add_subplot(212)  # this will show the frequency data
        '''
        Plot the data obtained from the iSpin Labview interface
        '''
        plt.figure(1, figsize = (6,5) )
        sp1.axhline(color ='r')
        sp1.axvline(color ='r')
        t = self.data['time']
        sp1.plot(t,self.data['real'], 'bo-')  # real part (blue)
        sp1.plot(t,self.data['imag'], 'ro-')  # imaginary part (red)
        sp1.plot(t,abs(self.data['complex']),'ko-')   # absolute value (black)
        sp1.set_xlabel('Time (sec)',fontsize=14)
        sp1.set_ylabel('iSpin CPMG Data',fontsize=14)
        sp1.set_xlim(t[0],t[-1])

        #sp1.show()                                      

        sp2.axhline(color ='r')
        sp2.axvline(color ='r')
        tfit = np.linspace(0,texpdata[-1],num=50)
        expfit = fitfunc(tfit,A_nlfit,T2_nlfit,y0_nlfit)
        sp2.plot(tfit,expfit,'b-')
        sp2.plot(texpdata,expdata, 'bo')  # plot the data points (blue)

        sp2.text(0.3*texpdata[-1], 0.7*expdata[0],
             '$T_2 \, =\, {0:6.4f} \pm {1:6.5f}$ s '.format(T2_nlfit, T2sig_nlfit), ha='left', va='bottom', size='large')
        sp2.set_xlabel('Echo Time (sec)',fontsize=14)
        sp2.set_ylabel('Echo Magnitude',fontsize=14)

        xrange = texpdata[-1]-texpdata[0]
        sp2.set_xlim(texpdata[0]-0.03*xrange,texpdata[-1]+0.03*xrange)
        #sp2.set_ylim(0,expdata[0])

        plt.show()

    # this implements ispin_nmr_T1_analysis
    def T1_analysis( self , dirname="" ):
        '''
        Inputs:
        dirname - (string) name of the directory containing files. one file for
        each value of tau

        Outputs:
        T1_nlfit - (float) the value of T1 from fit

        This program determines T1 from a set of spincore ".txt" files, generated by
        running the spincore batch file called 'T1_IR_sweep.bat'.
        Each ".txt" file contains the data from an "inversion recovery" sequence, where a pi pulse
        inverts the signal, and after a variable delay "tau", a pi/2 pulse is applied
        and the resulting free-induction decay (fid) is recorded.
        Each file is parametrized by the value of tau.
        Fitting the size of the fid as a function of tau to an exponential decay allows one to extract the spin-lattice relaxation
        time T1.

        More specifically, this program:
        - plots the data from each of the ".txt" data files.
        - Integrates over the resonance line in the frequency spectrum to get the 'size'
          of the signal for each value of tau.
        - The integral of the data from each file is rotated in the complex plane to
          make it real, in such a way to compensate for slow phase rotations over time.
        - Fits the signal size as a function of tau to a decaying exponental and prints
          the fit parameters (including value of T1), and plots both the data and fit.

        ======================================
         Instructions for using this program:
        ======================================
        User needs to set values of:

        tau_min     # minimum value of tau (in ms)
        delta_tau   # difference between consecutive values of tau (in ms)
        n_tau       # number of different values of tau:  this is the number of
                    # files in the directory
        These values can be obtained from the corresponding quantities: TAU_MIN,
        DELTA_TAU, and N_TAU in the 'T1_IR_sweep.bat' file.  Note that the units of
        these quantities in the .bat file are microseconds.
            
        The range of integration in frequency space (in Hz) for computation of the
        "size" of the FID.  This can be determined by looking at a plot of the FID
        data and the FFT.

        f_min       # minum value of frequency range (in Hz)
        f_max       # maximum value of frequency range
            
        Initial guesses for the values of the exponential fit perameters that model
        the data:  y = A exp(-t/T1) + y0

        A0          # initial guess for A
        T10         # initial guess for T1
        y00         # initial guess for y0
        '''
        # range of tau used in batch file
        tau_min = 10    # in ms
        delta_tau = 50  # tau increment
        n_tau = len(os.listdir(dirname))  # number of different values of tau:  this is the number of 
                        # files in the directory
        tau_max = tau_min + delta_tau * (n_tau - 1)

        # The range of integration in frequency space (in Hz) for computation of the 
        # "size" of the FID.  
        f_min = -400 #(Hz)
        f_max = 400

        # The factor by which the frequency scale is expanded around f=0 in the 
        # frequency plot.
        # sf = 50

        # Initial guess for T1 fit parameters
        A0 = -20
        T10 = 100 # (ms)
        y00 = 10


        signal = np.array([])  # array where fid sizes are stored 
        zsignal = np.array([]) # complex array

        # The following reads in FID data, takes FFT, plots data and FFT, 
        # integrates FFT and appends complex valued integral to array zsignal

        print('\nFile Name\t\tFrequency Integral/10^12')
        print('---------\t\t------------------------')
        for filename in os.listdir( dirname ):
            full_path = os.path.join( dirname, filename )

            # read data from file 
            self.load_data(full_path,verbose=False)
            # self.plot_fid(sf=sf)
            
            # Integrate over the frequency data
            fintegral = intsimps(self.data['fza'],self.data['freq'],f_min,f_max)
            print(filename,':\t\t{: 1.3e} + {: 1.3e}j'\
                .format(fintegral.real/10**12,fintegral.imag/10**12))
            # Add the integrated signal to the "signal" vs "tau" data
            signal = np.append(signal, fintegral.real/10**12)
            zsignal = np.append(zsignal, fintegral/10**12)

        print("\n complex t1 data:\n-------------------\n ",zsignal)
        print("number of points = ",len(signal))
        print("\n")

        realsignal = complexArrayToReal(zsignal)

        print("\n real t1 data:\n-------------------\n ",realsignal)

        # values of tao for which data were taken
        tau = np.linspace(tau_min, tau_max, n_tau)

        assert len(tau) == len(realsignal), "xdata not same length as ydata"
        nlfit, nlpcov = scipy.optimize.curve_fit(f=fitfunc, xdata=tau, \
                ydata=realsignal, p0=[A0, T10, y00])

        # Best values of fit parameters 
        A_nlfit = nlfit[0]
        T1_nlfit = nlfit[1]
        y0_nlfit = nlfit[2]

        # best case scenario of standard deviation of each parameter
        Asig_nlfit =  np.sqrt(nlpcov[0][0])
        T1sig_nlfit = np.sqrt(nlpcov[1][1])
        y0sig_nlfit = np.sqrt(nlpcov[2][2])

        print('\n')
        print('=================================')
        print('       Fit Paremeters    ')
        print('  T1 = {: 1.2f}   +- {:1.2f} ms'.format(T1_nlfit,T1sig_nlfit))
        print('  A  = {: 1.2e} +- {:1.1e}'.format(A_nlfit,Asig_nlfit))
        print('  y0 = {: 1.2e} +- {:1.1e}'.format(y0_nlfit,y0sig_nlfit))
        print('=================================')

        taus = np.linspace(0, 1.05*tau_max, 5*n_tau)
        # draw the figure of signal vs. tau
        fig, ax = plt.subplots()
        ax.plot(np.linspace(tau_min,tau_max,n_tau),realsignal, 'ob', \
                label='Real Signal') # plot the pts
        ax.plot(taus,fitfunc(taus,A_nlfit,T1_nlfit,y0_nlfit),'-r',\
                label='Fit to Signal') # plot the fit
        ax.set_xlabel('Delay Time, $\\tau$ (ms)',fontsize=14)  # x-axis label
        ax.set_ylabel('FID Amplitude',fontsize=14)    # y-axis label
        # print value of T1
        print('Value of A_nlfit:',A_nlfit)
        plt.text(0.7*tau_max, 0.1*max(realsignal) + 0.9*min(realsignal),
        r'$y=y_0+A e^{-\tau/T_1}$'+'\n\n'+r'$T_1=$' +
        '{:.5f}ms\n'.format(T1_nlfit)+'$A=$'+'{:.5f}'.format(A_nlfit)+\
            '\n $y_0=${:.5f}'.format(y0_nlfit),fontsize=14)
        ax.legend()
        filename = "t1_" + dirname
        plt.savefig("../../img/")
        return T1_nlfit, T1sig_nlfit

    def plot_ispin_nmr_data_FFT( self , fname , sf=1 ):
        """
        fname - (string) input filename
        sf - (float) the factor by which frequency scale is expanded around f=0


        This routine reads in a spincore ".txt" file, and plots the time data
        in that file as well as the frequency data (FFT).  Since the interesting
        part of the data is at low frequencies, the frequency range of the plot is
        reduced by a scale factor 'sf'.

        """
        fig,ax = plt.subplots(2,1,figsize=(10,10))
        self.load_data( fname )
        N = self.data.shape[0]
        bw = self.metadata['bandwidth']
        # change time units to msec
        self.data['time'] = self.data['time'] * 1000.0
        self.data['magnitude'] = abs(self.data['complex'])
        self.data.plot( ax=ax[0] , x='time' , y='magnitude' , fmt='-k', linewidth=0.5)
        self.data.plot( ax=ax[0] , x='time' , y='real' , fmt='-b')
        self.data.plot( ax=ax[0] , x='time' , y='imag' , fmt='--r')
        ax[0].set_xlabel("Time (msecs)" ,fontsize=14)
        ax[0].set_ylabel("Signal", fontsize=14 )
        ax[0].set_xlim(self.data['time'][0],self.data['time'][1])

        # compute fft
        fft = np.ftt.fttshift( np.fft.fft( self.data['complex'] ) )
        # compute frequencies
        f = ( bw / N ) * np.arange( N ) - bw / 2

        fscale = 1. / 1000.0
        ax[1].plot( f * fscale , fft.real , '-b' )
        ax[1].plot( f * fscale , fft.imag , '--r' )
        ax[1].plot( f * fscale , np.sqrt(fft.real**2 + fft.imag**2) , '-k' )
        ax[1].set_xlabel('Frequency (kHz)' , fontsize=14)
        ax[1].set_ylabel('Signal',fontsize=14)
        ax[1].set_xlim( f[0] / sf * fscale , f[-1] / sf * fscale )
        plt.show()

    # implements NMR_diffusion_fit_array
    def NMR_diffusion_fit_array( self , infileName = "" ):
        '''
        This routine uses the Levenburg-Marquardt algorithm to fit a set of data 
        points to the function A*np.exp(-((gamma*t)**3)/6) + y0, which describes the 
        amplitude of a Hahn echo in the presence of a magnetic field gradient and 
        diffusion.  From the fit, one can determine the constant of self diffusion.
        The Hahn echo amplitudes are obtained from an array pasted into the program.
        Formally called NMR_diffusion_fit_sec
        '''
        self.load_data( infileName )

        # assign the data to variables with shorter names
        #t = s1.time_ms                        
        #s = s1.echo_size  
        #sigs = s1.error
        print("\n\n")
        print("---------------------------------------------------------------------------")
        print("File NMR_diffusion_fit_2.py")
        print("This routine to uses the Levenburg-Marquardt algorithm to fit a set of data" )
        print("points to the function A*np.exp(-((gamma*t)**3)/6) + y0, which describes the" )
        print("amplitude of a Hahn echo in the presence of a magnetic field gradient and")
        print("diffusion.  From the fit, one can determine the constant of self diffusion.")
        print("---------------------------------------------------------------------------")

        t =0.001* np.array([
        10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150
        ])
        s =  np.array([
#1.0, 0.9487684636806164, 0.87927551477236121, 0.7899413674849104, 0.67476475187285079, 0.55333667677793019, 0.42879681796822483, 0.31471852300524433, 0.22237743704651372, 0.14620147343755366, 0.094726254344446897, 0.060745843884831202, 0.038972396685041162, 0.02688710023044736, 0.019488148512798727, 0.017466942516494034, 0.016436107290663301, 0.015608199416276905, 0.015518620226368332, 0.014596982339219428
#1.0, 0.94718535466131604, 0.87500470082775494, 0.78395929858123392, 0.66399799540827709, 0.53876116636950855, 0.41159572116718196, 0.29583746678893802, 0.20333697170540407, 0.12903062779845367, 0.078455170818481856, 0.045821627617545005, 0.025183048039646092, 0.014545226164819645, 0.0081264606110035813, 0.0061267654812352376, 0.0059990251642263329, 0.0048322601995357062, 0.0048984050766543519, 0.0052666298354899378
        1.0, 0.75545062492843473, 0.53699911740608619, 0.38510282009102964, 0.27847165418385794, 0.21234022973322111, 0.15533993560354881, 0.11370538514674253, 0.10819140369627162, 0.10780496529924961, 0.087014584447802718, 0.088436397387235063, 0.08460463013915677, 0.076681062211558376, 0.082169398695911708
        ])
        print("t = ", t)
        print("s = ", s)
        '''
        -- information on nonlinear curve fitting --

        nlfit,nlpcov = scipy.optimize.curve_fit(f, xdata, ydata, p0=[a0, b0, ...], 
          sigma=None, **kwargs)

        * f(xdata, a, b, ...): is the fitting function where xdata is an array of values
           of the independent variable and a, b, ... are the fitting parameters, however 
           many there are, listed as separate arguments.  f(xdata, a, b, ...) should 
           return the y value of the fitting function.
        * xdata: is the array containing the x data.
        * ydata: is the array containing the y data.
        * p0: is a tuple containing the initial guesses for the fitting parameters. The 
          guesses for the fitting parameters are set equal to 1 if they are left 
          unspecified.
        * sigma: is the array containing the uncertainties in the y data.
        * **kwargs: are keyword arguments that can be passed to the fitting routine 
          numpy.optimize.leastsq that curve_fit calls. These are usually left unspecified.

        '''
        # Define nonlinear fitting function.
        def f(t, A, alpha, y0):         
            return A*np.exp(-(alpha*(t**3))) + y0

        # Initial guesses: modify these if fit doesn't converge.
        A0 = 1.0;
        alpha0 = 10**(3); y00 = 0.0;

        # This is the function that does the nonlinear fit:
        #nlfit, nlpcov = scipy.optimize.curve_fit(f, t, s, p0=[A0, gamma0, y00], sigma=None)
        nlfit, nlpcov = scipy.optimize.curve_fit(f, t, s, p0=[A0, alpha0, y00], sigma=None)

        # These are the parameter estimates (assigned to more readible names):
        A_nlfit = nlfit[0]
        alpha_nlfit = nlfit[1]
        y0_nlfit = nlfit[2]
        Asig_nlfit =  np.sqrt(nlpcov[0][0])
        alphasig_nlfit = np.sqrt(nlpcov[1][1])
        y0sig_nlfit = np.sqrt(nlpcov[2][2])

        '''
        The following statements generate formatted output of the fit parameters.  
        The number before the colon refers to the sequence of arguments in the .format 
        command.  In "{0:6.3f}", the 0 refers to the first argument in the .format() 
        command, the 6 refers to the total width of the field, and the 3 refers to the 
        number of digits after the decimal point.  
        See http://docs.python.org/tutorial/inputoutput.html for more information.
        '''

        # Compute reduced chi square for nonlinear fit.
        #redchisqrNL = (((s - f(t, A_nlfit, alpha_nlfit, y0_nlfit))/sigs)**2).sum()/float(len(t)-2)

        # Create an array of times t for the purpose of plotting the fit:
        tfit = np.arange(0.0, t[-1] + (t[1]-t[0])/2, 0.0001)

        # Generate y-values from parameters determined from the curve fit, so that 
        # we can plot the fit on top of the data:
        sfit = f(tfit, A_nlfit, alpha_nlfit, y0_nlfit)

        plt.figure(1, figsize = (8,4.5) )
        plt.plot(t, s, 'ob', label='Data')
        #plt.errorbar(t, s, sigs, fmt='bo')
        plt.plot(tfit,sfit,'r', label='Fit')
        plt.legend(loc='upper right' )
        # Plot some text with model equation and values of fit parameters.
        plt.text(0.010, 0.4,
            '$y \, =\, A e^{-\\alpha t^3} + y_0$', 
            ha='left', va='bottom', size='large')
        plt.text(0.010, 0.3,
            '$\\alpha \, =\, ({0:6.4g} \pm {1:5.2g})/s^3$'.format(alpha_nlfit, alphasig_nlfit),
            ha='left', va='bottom', size='large')
        plt.text(0.010, 0.2,
            '$A  \, =\, {0:6.3g} \pm  {1:6.1g}$'.format(A_nlfit, Asig_nlfit),
            ha='left', va='bottom', size='large')
        plt.text(0.010, 0.1,
            '$y_0 \, =\, {0:6.3g} \pm {1:6.1g}$'.format(y0_nlfit, y0sig_nlfit),
            ha='left', va='bottom', size='large')
        plt.xlabel('Time (s)',fontsize=14)
        plt.ylabel('Echo Amplitude',fontsize=14)
        plt.xlim(0.0,t[-1] + (t[1]-t[0])/2)
        plt.ylim(-0.05,1.05)
        plt.show()

    # implements plot_ispin_data_sequence
    def plot_ispin_data_sequence( self , infileName = ""):
        '''
        This routine reads in and plots a sequence of spincore '.txt' files.  The plots 
        are saved to disk with filename 'xxx.png', where 'xxx.txt' is the file name 
        containing the data.  Derived from the program plot_ispin_forloop, written by 
        Greg Lemberskiy.  

        Last update:  1/30/2012, 10/7/2012, 
                      1/21/2013 (changed .pdf to .png) by Tycho Sleator
        '''

# The following is the filename containing the data
        # fname = "sample_NMR_file.txt"
        fname = infileName
        fnums = range(40)

        for fname in fnums:    
            name  = "stim_echo_sweep_r5"+str(fname)+".txt"
            print(name)
            infile = open(name,"r")
            text = infile.read()      # read file into a string
            infile.close()

            index = text.find("@SW=") # Find the position of "@SW="
            text2 = text[index:-1]    # Create new string beginning at "@SW="
            index2 = text2.find('\n') # Find the next CR in this string

            bw = float(text2[4:index2]) # This gives the bandwidth
            print('bw = ',bw)
            print('1/bw = ',1/bw) # Note that the time interval between points is 1/bw
            
            # Read the data from the the file starting on line 13
            self.load_data( name )
            
            t =  (1/bw)*np.arange(self.data.shape[0]/2)  #time data
            
            # get maximum value of the data

            # create the figure
            fig1   = plt.figure(figsize=(8,10))
            ax1    = fig1.add_subplot(211)
            ax2    = fig1.add_subplot(212)


            # Top Figure (Re and Im pargs): ax1
            # draw x and y axes
            ax1.axhline(color ='k')
            ax1.axvline(color ='k')

            # plot the points
            ax1.plot(t,self.data['real'], '-b')  # plot the real part (blue)
            ax1.plot(t,self.data['imag'], '-r')  # plot the imag part (red)

# label the axes
            ax1.set_xlabel('Time (sec)',fontsize=14)
            ax1.set_ylabel('Signal',fontsize=14)
# specify the plot limits
            ax1.set_xlim(t[0],t[-1])
            ax1.set_ylim(-1.2e8, 1.0e8)

# Bottom Figure (magnitude): ax2 
# draw x and y axes
            ax2.axhline(color ='k')
            ax2.axvline(color ='k')

            magnitude = ((self.data['real'])**2 + (self.data['imag'])**2)**(0.5)

            # plot the points
            ax2.plot(t,magnitude)
            # label the axes
            ax2.set_xlabel('Time (sec)',fontsize=14)
            ax2.set_ylabel('Signal',fontsize=14)
            # specify the plot limits
            ax2.set_xlim(t[0],t[-1])
            ax2.set_ylim(0, 1.2e8)
            # display the figure

            plt.savefig(name.replace(".txt",".png"))
            plt.show()

    # plot_ispin_nmr_data
    def plot_ispins_nmr_data( self , infileName = "" ):
        '''
        file:  plot_ispin_nmr_data2.py
        This routine reads in a spincore ".txt" file, and plots the data in that file
        Unlike the file 'plot_ispin_nmr_data.py' it doesn't automatically rescale the
        data to fit between 0 and 1.  This has an advantage when plotting several data
        sets on the same plot.  
        Last update:  9/25/2012 by Tycho Sleator
        '''

        # fname = "CPMG.txt"
        self.load_data(infileName)


# get maximum value of the data
        # maxza = np.max([max(self.data['real']),max(self.data['imag'])])  # maximum value

# create the figure
        plt.figure(1, figsize = (8,5) )               

# draw x and y axes
        plt.axhline(color ='r')
        plt.axvline(color ='r')
        print('len(az.real)=',len(self.data['real']))
        print('len(t)=',len(self.data['time']))


# plot the points
        plt.plot(self.data['time'],np.abs(self.data['complex']),'-k',linewidth=2) # plot the absolute value (black)
        plt.plot(self.data['time'],self.data['real'], '-b')  # plot the real part (blue)
        plt.plot(self.data['time'],self.data['imag'], '-r')  # plot the imaginary part (red)

# label the axes
        plt.xlabel('Time (sec)',fontsize=14)
        plt.ylabel('Signal',fontsize=14)

# specify the plot limits
        plt.xlim(self.data['time'][0],self.data['time'][-1])

# display the figure
        plt.show()

    def plot_ispin_nmr_data( self , infileName = ""):
        '''
        file:  plot_ispin_nmr_data2.py
        This routine reads in a spincore ".txt" file, and plots the data in that file
        Unlike the file 'plot_ispin_nmr_data.py' it doesn't automatically rescale the
        data to fit between 0 and 1.  This has an advantage when plotting several data
        sets on the same plot.  
        Last update:  9/25/2012 by Tycho Sleator
        '''
        self.load_data( infileName )
        # maxza = np.max([max(self.data['real']),max(self.data['imag'])])  # maximum value
        t = self.data['time']
        za = self.data['complex']
        plt.figure(1, figsize = (8,5) )               
        plt.plot(t,np.abs(za),'-k',linewidth=2) # absolute value (black)
        plt.plot(t,self.data['real'], '-b')  # real part (blue)
        plt.plot(t,self.data['imag'], '-r')  # imaginary part (red)
        plt.xlabel('Time (sec)',fontsize=14)
        plt.ylabel('Signal',fontsize=14)
        plt.xlim(t[0],t[-1])
        plt.show()                                      
