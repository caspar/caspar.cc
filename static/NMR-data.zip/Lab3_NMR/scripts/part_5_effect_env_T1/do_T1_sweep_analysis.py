if __name__ == "__main__":
    import sys
    import matplotlib.pyplot as plt
    import numpy as np
    sys.path.append("../python_scripts")
    from NMR_Data_Driver import DataDriver
    data_path = "../../data/Part 5 - The effect of local env on the value of T1/"
    driver = DataDriver()
    subdirs = ['10mM/run 3','5mM','2.5mM','H2O']
    t1s = []
    for subdir in subdirs:
        t1s.append(driver.T1_analysis(data_path + subdir)[0])
    print("T1 values: ",t1s)
    t1s = np.array(t1s)
    concentrations = np.array([10,5.0,2.5,0.0])
    fig,ax = plt.subplots(1)
    plt.xlabel("Concentration [mM]")
    plt.ylabel(r"$T_1^{-1}$")
    plt.title("Plot of Inverse Relaxation Time versus Concentration")
    plt.plot(concentrations,1/t1s,c='r')
    plt.savefig("../../img/inv_t1.png",format='png',dpi=100)
    plt.show()
