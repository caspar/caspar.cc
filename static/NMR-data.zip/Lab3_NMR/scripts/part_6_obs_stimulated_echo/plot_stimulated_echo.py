if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import sys
    sys.path.append("../python_scripts")
    from NMR_Data_Driver import DataDriver
    data_path = "../../data/Part 7 - Stimulated Echo/"
    driver = DataDriver()
    title=''
    driver.load_data(fname=data_path+"stim_echo.txt")
    driver.plot_fid(outfileName='../../stim_echo',title=title)
    plt.show()
